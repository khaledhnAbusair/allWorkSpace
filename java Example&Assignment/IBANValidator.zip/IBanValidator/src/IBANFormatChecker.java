import java.io.*;

public class IBANFormatChecker {
	private String[] ibanCountryNames;
	private String[] ibanCountryCodes;
	private String[] ibanFormats;
	private int[] ibanCodeLengths;
	private int numberOfCodes;

	private final int COUNTRY_NAME_ORDER = 0;
	private final int COUNTRY_CODE_ORDER = 1;
	private final int IBAN_FORMAT_ORDER = 2;
	private final int IBAN_LENGTH_ORDER = 3;
	private final int NUM_OF_PARAMETERS = 4;
	private final int COUNTRY_CODE_LENGTH = 2;
	private final int POS_AFTER_COUNTRY_CODE = 2;
	private final int POS_AFTER_TYPE = 2;
	private final int POS_OF_TYPE = 1;
	private final char NUM_TYPE_SEPARATOR = '!';
	private final char ALPHA_TYPE = 'a';
	private final char NUM_TYPE = 'n';
	private final char MIXED_TYPE = 'c';
	private final String INVALID_FILE_FORMAT = "Invalid file format";
	private final String PARAMETERS_SEPARATOR = ",";

	public IBANFormatChecker(String ibanFilePath) throws IOException {
		File file = new File(ibanFilePath);
		FileReader fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);

		String line = bufferedReader.readLine();

		if (line == null) {
			bufferedReader.close();
			throw new IllegalArgumentException(INVALID_FILE_FORMAT);
		}

		loadInformation(bufferedReader, line);
	}

	private void loadInformation(BufferedReader bufferedReader, String firstLine) throws IOException {
		try {
			numberOfCodes = Integer.parseInt(firstLine);
		} catch (NumberFormatException ex) {
			bufferedReader.close();
			throw new IllegalArgumentException(INVALID_FILE_FORMAT);
		}

		initializeArrays(bufferedReader);
		bufferedReader.close();
	}

	private void initializeArrays(BufferedReader bufferedReader) throws IOException {
		String line;

		ibanCountryNames = new String[numberOfCodes];
		ibanCountryCodes = new String[numberOfCodes];
		ibanFormats = new String[numberOfCodes];
		ibanCodeLengths = new int[numberOfCodes];

		for (int i = 0; i < numberOfCodes; i++) {
			line = bufferedReader.readLine();
			if (line == null) {
				bufferedReader.close();
				throw new IllegalArgumentException(INVALID_FILE_FORMAT);
			}

			parseLine(line, i);
		}
	}

	private void parseLine(String line, int index) {
		String info[] = line.split(PARAMETERS_SEPARATOR);
		if (info.length != NUM_OF_PARAMETERS)
			throw new IllegalArgumentException(INVALID_FILE_FORMAT);

		ibanCountryNames[index] = info[COUNTRY_NAME_ORDER];
		ibanFormats[index] = info[IBAN_FORMAT_ORDER];

		String countryCode = info[COUNTRY_CODE_ORDER];
		if (countryCode.length() != COUNTRY_CODE_LENGTH)
			throw new IllegalArgumentException(INVALID_FILE_FORMAT);

		int codeLength;
		try {
			codeLength = Integer.parseInt(info[IBAN_LENGTH_ORDER]);
		} catch (NumberFormatException ex) {
			throw new IllegalArgumentException(INVALID_FILE_FORMAT);
		}

		ibanCountryCodes[index] = countryCode;
		ibanCodeLengths[index] = codeLength;
	}

	private boolean isFormatCorrect(String iban, int index) {
		int posNumStart = POS_AFTER_COUNTRY_CODE;
		int posNumEnd;
		int posIBAN = POS_AFTER_COUNTRY_CODE;
		String ibanFormat = ibanFormats[index];
		String number;
		int numOfChars;
		char type;

		while (posNumStart != ibanFormat.length()) {
			posNumEnd = ibanFormat.indexOf(NUM_TYPE_SEPARATOR, posNumStart);
			if (posNumEnd == -1)
				throw new IllegalArgumentException(INVALID_FILE_FORMAT);

			number = ibanFormat.substring(posNumStart, posNumEnd);
			try {
				numOfChars = Integer.parseInt(number);
			} catch (NumberFormatException ex) {
				throw new IllegalArgumentException(INVALID_FILE_FORMAT);
			}

			type = ibanFormat.charAt(posNumEnd + POS_OF_TYPE);
			if (!isPartCorrect(iban.substring(posIBAN, posIBAN + numOfChars), type))
				return false;

			posIBAN += numOfChars;
			posNumStart = posNumEnd + POS_AFTER_TYPE;
		}

		return true;
	}

	private boolean isPartCorrect(String part, char type) {
		switch (type) {
		case ALPHA_TYPE:
			return isAllAlpha(part);
		case NUM_TYPE:
			return isAllNum(part);
		case MIXED_TYPE:
		}
		return true;
	}

	private boolean isAllNum(String string) {
		char current;
		boolean cond;

		for (int i = 0; i < string.length(); i++) {
			current = string.charAt(i);
			cond = current >= '0' && current <= '9';
			if (!cond)
				return false;
		}

		return true;
	}

	private boolean isAllAlpha(String string) {
		char current;

		for (int i = 0; i < string.length(); i++) {
			current = string.charAt(i);

			if (current < 'A' || current > 'Z')
				return false;
		}

		return true;
	}

	public boolean isIBANFormatValid(String iban) {
		String countryCode = iban.substring(0, COUNTRY_CODE_LENGTH);

		int i;
		for (i = 0; i < numberOfCodes; i++) {
			if (ibanCountryCodes[i].equals(countryCode))
				break;
		}

		if (i == numberOfCodes)
			return false;
		if (iban.length() != ibanCodeLengths[i])
			return false;
		if (!isFormatCorrect(iban, i))
			return false;

		return true;
	}
}
