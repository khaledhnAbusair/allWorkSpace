import java.io.*;

public class IBANValidator {
	private String IBAN;
	private final int SEVEN_DIGITS = 7;
	private final int CHARS_TO_MOVE = 4;
	private final long TEN_POW_SEVEN_MOD_97 = 10_000_000 % 97;
	private final String IBANFilePath = "C:\\Users\\u624\\Desktop\\workspace\\IBanValidator\\src\\IBAN.txt";
	private final String ERROR_WHILE_INIT_INFO = "Error while initializing necessary information.";

	public IBANValidator(String IBANCode) {
		// Preliminary step: delete all non-alphanumeric characters
		IBAN = removeExcessChars(IBANCode.toUpperCase());
	}

	public boolean isValid() {
		// Step 0: Check IBAN format
		IBANFormatChecker ibanFormatChecker;

		try {
			ibanFormatChecker = new IBANFormatChecker(IBANFilePath);
		} catch (IOException ex) {
			System.out.println(ERROR_WHILE_INIT_INFO);
			System.out.println(ex.getMessage());
			return false;
		} catch (IllegalArgumentException ex) {
			System.out.println(ERROR_WHILE_INIT_INFO);
			System.out.println(ex.getMessage());
			return false;
		}

		if (ibanFormatChecker.isIBANFormatValid(IBAN)) {
			// Step 1: Move first 4 characters to the right of the IBAN
			String result = IBAN.substring(CHARS_TO_MOVE) + IBAN.substring(0, CHARS_TO_MOVE);
			// Step 2: Convert alphabets to numbers
			result = convertLettersToNumbers(result);
			// Step 3: Calculate number % 97
			return mod97(result) == 1;
		}

		return false;
	}

	private int mod97(String number) {
		String digits;
		int start = number.length();
		int end = start;
		long base = 1;
		long digitsMod;
		long result = 0;

		while (start > 0) {
			start -= SEVEN_DIGITS;
			if (start < 0)
				start = 0;

			digits = number.substring(start, end);
			digitsMod = Long.parseLong(digits) % 97;
			digitsMod = (digitsMod * base) % 97;
			result = (result + digitsMod) % 97;

			base = (base * TEN_POW_SEVEN_MOD_97) % 97;
			end -= SEVEN_DIGITS;
		}

		return (int) result;
	}

	private boolean isAlphaNumeric(char chr) {
		boolean cond1 = chr >= 'A' && chr <= 'Z';
		boolean cond2 = chr >= '0' && chr <= '9';

		if (!cond1 && !cond2)
			return false;
		return true;
	}

	private String removeExcessChars(String string) {
		String result = "";
		int i;
		char current;

		for (i = 0; i < string.length(); i++) {
			current = string.charAt(i);
			if (isAlphaNumeric(current))
				result += current;
		}

		return result;
	}

	private String convertLettersToNumbers(String IBANCode) {
		int i;
		char current;
		int num;
		String result = "";

		for (i = 0; i < IBANCode.length(); i++) {
			current = IBANCode.charAt(i);
			if (current >= 'A' && current <= 'Z') {
				num = (int) (current - 'A' + 10);
				result += Integer.toString(num);
			} else {
				result += current;
			}
		}

		return result;
	}
}
