
public class Test {
	public static void main(String[] args) {
		IBANValidator ibanValidator = new IBANValidator("SC18SSCB11010000000000001497USD");
		System.out.println(ibanValidator.isValid());
	}
}
