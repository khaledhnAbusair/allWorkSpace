/**
 * 
 */
package com.progressoft.jip.bankapplication;

import java.util.Date;

/**
 * @author u620
 *
 */
public class TransactionOption extends Option{

	private Account from;
	private Account to;
	private double amount;
	private Date date;
	private PaymentPurpose paymentPurpose;
	
	public TransactionOption(String description) {
		super(description);
	}

	@Override
	public void doOperation() {
	UI.show("Transaction option");
		
	}
	
}
