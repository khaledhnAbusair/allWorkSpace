/**
 * 
 */
package com.progressoft.jip.bankapplication;

/**
 * @author Anas Hamed & Khaled
 *
 */
public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//UI.interact();
		
		String iban = "JO94 CBJO 0010 0000 0000 0131 0003 02";
		UI.show(iban);
		
		if(IBANValidator.validateIBAN(iban))
			UI.show("IBAN checks out");
		else
			UI.show("IBAN invalid");
	}
}
