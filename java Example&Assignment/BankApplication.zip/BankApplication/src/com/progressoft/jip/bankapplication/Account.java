/**
 * 
 */
package com.progressoft.jip.bankapplication;

import java.util.ArrayList;
import java.util.Currency;
import java.util.Scanner;

/**
 * @author u620
 *
 */
public class Account {
	private long accountNumber;
	private String accountName;
	private String accountOwnerName;
	private String IBAN;
	private String swiftCode;
	private Currency currency;
	
	public Account() {
		
	}
}
