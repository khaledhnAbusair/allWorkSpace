package com.progressoft.jip.bankapplication;

public enum PaymentPurpose {
	SALARY("0101");
	private final String code;
	
	private PaymentPurpose(String code) {
		this.code = code;
	}
}
