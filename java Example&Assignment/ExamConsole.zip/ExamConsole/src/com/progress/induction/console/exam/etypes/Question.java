package com.progress.induction.console.exam.etypes;

import java.util.ArrayList;
import java.util.Scanner;

public abstract class Question {

	private String questionContent;
	private ArrayList<String> choices;

	public Question(String questionContent, ArrayList<String> choices) {
		this.questionContent = questionContent;
		this.choices = choices;
	}

	public ArrayList<String> getChoices() {
		return choices;
	}

	public String getQuestionContent() {
		return questionContent;
	}

	public void setQuestionContent(String questionContent) {
		this.questionContent = questionContent;
	}

	public abstract boolean displayQuestion(Scanner scanner);

}
