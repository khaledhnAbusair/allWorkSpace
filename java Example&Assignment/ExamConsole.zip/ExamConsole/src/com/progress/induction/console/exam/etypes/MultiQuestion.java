package com.progress.induction.console.exam.etypes;

import java.util.ArrayList;
import java.util.Scanner;

public class MultiQuestion extends Question {
	private ArrayList<String> correctAnswer;

	public MultiQuestion(String questionContent, ArrayList<String> choices, ArrayList<String> correctAnswer) {
		// TODO Auto-generated constructor stub
		super(questionContent, choices);
		this.correctAnswer = correctAnswer;

	}

	@Override
	public boolean displayQuestion(Scanner scanner) {
		// TODO Auto-generated method stub
		System.out.println(this.getQuestionContent());
		for (String choice : this.getChoices())
			System.out.println(choice);
		System.out.println("Your Choices ? ");
		String choices = scanner.next();
		String[] choiceFiled = choices.split(",");

		boolean correct = true;
		System.out.println("Sizes: " + choiceFiled.length + " " + this.correctAnswer.size());
		if (choiceFiled.length == this.correctAnswer.size()) {

			for (String choiceNum : choiceFiled) {
				// System.out.println("multi: " +
				// this.getCorrectAnswer().get(Integer.parseInt(choiceNum) -
				// 1));

				if (!this.correctAnswer.contains(choiceNum + "")) {
					correct = false;
					return false;
				}
			}

		} else {
			return false;
		}

		return correct;
	}
}
