package com.progress.induction.console.exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.progress.induction.console.exam.etypes.EssayQuestion;
import com.progress.induction.console.exam.etypes.MultiQuestion;
import com.progress.induction.console.exam.etypes.Question;
import com.progress.induction.console.exam.etypes.SingleQuestion;
import com.progress.induction.console.exam.etypes.YNQuestion;

public class Driver {
	public static ArrayList<Question> questions = new ArrayList<>();
	public static Map<String, Integer> usersScores = new HashMap<String, Integer>();

	private static final int DISPLAY_RESULTS = 2;
	private static final int TAKE_EXAM = 1;
	private static final int EXIT_PROGRAME = 3;

	public static int userScore = 0;
	public static Scanner scanner;
	public static Scanner scanner2;

	public static void main(String[] args) {
		prepareQuestions();
		displayMenu();
		executeSystem();

	}

	public static void prepareQuestions() {

		addYesNoQuestions();

		addEssayQuestions();

		addSingleQuestions();

		addMultipleQuestions();

	}

	private static void addMultipleQuestions() {
		Question multi1 = new MultiQuestion("What is true for �Ahmad�.replace(�a�,�A�)",
				new ArrayList<>(
						Arrays.asList("1-There is no such method as replace", "2-The result will produce �ahmAd�",
								"3- A new string will be returned which has the contents of �AhmA�",
								"4- replace is an instance method")),
				new ArrayList<>(Arrays.asList("1")));

		questions.add(multi1);

		Question multi2 = new MultiQuestion("If class B extends A, what is true?",
				new ArrayList<>(Arrays.asList(
						"1- You can assign a reference for A to a reference to B without explicit casting",
						"2- Object x = new A(); will not compile",
						"3- Object a = new A(); B b = (B)a; will throw a ClassCastException on run time.",
						"4- A a = new A(); A a = new B(); will not compile")),
				new ArrayList<>(Arrays.asList("1")));

		questions.add(multi2);
	}

	private static void addSingleQuestions() {
		Question single1 = new SingleQuestion("What is true for Integer x=10?",
				new ArrayList<>(Arrays.asList("1-the cope will not compile",
						"2-The value of 10 will be represented as an Integer Object", "3- 10 is a short literal",
						"4- The code will compile but it will throw a RuntimeException in runtime")),
				4);
		questions.add(single1);

		Question single2 = new SingleQuestion("I _____ tennis every Sunday morning",
				new ArrayList<>(Arrays.asList("1- playing", "2- play", "3- am playing", "4- am plan")), 2);
		questions.add(single2);

		Question single3 = new SingleQuestion("How many students in your class _____ from Korea?",
				new ArrayList<>(Arrays.asList("1- Comes", "2- come", "3- came", "4- are coming")), 4);
		questions.add(single3);

		Question single4 = new SingleQuestion("I ________ for my pen. Have you seen it?",
				new ArrayList<>(Arrays.asList("1- will look", "2- looking", "3- look", "4- am looking")), 4);
		questions.add(single4);
	}

	private static void addEssayQuestions() {
		Question Essay1 = new EssayQuestion("What is the capital of Canada?", null, "Ottawa");

		questions.add(Essay1);
		Question Essay2 = new EssayQuestion("What is the result of 3*4+5*10-20 ?", null, "42");

		questions.add(Essay2);
	}

	private static void addYesNoQuestions() {
		Question YN1 = new YNQuestion("Albert Einstein was born on1879 (Yes/No)",
				new ArrayList<>(Arrays.asList("Y", "N")), 'y');
		questions.add(YN1);
		Question YN2 = new YNQuestion("Instanceof operator is used to check if an instance belongs to a type",
				new ArrayList<>(Arrays.asList("Y", "N")), 'y');
		questions.add(YN2);
	}

	public static void executeSystem() {
		scanner = new Scanner(System.in);
		scanner2 = new Scanner(System.in);
		int choice = scanner.nextInt();
		while (choice <= 3) {

			switch (choice) {
			case TAKE_EXAM:
				takeExam();
				break;

			case DISPLAY_RESULTS:
				displayResult();
				break;

			case EXIT_PROGRAME:
				System.exit(0);
				break;

			}

			displayMenu();
			choice = scanner.nextInt();
			scanner.nextLine();
		}
	}

	private static void takeExam() {
		String userName;
		userScore = 0;
		System.out.println("Enter Your  Name :");
		userName = scanner.next();
		ArrayList<Integer> questionIndexs = generateQuestions();

		for (int i = 0; i < 5; i++) {
			Question question = questions.get(questionIndexs.get(i));
			boolean correct = question.displayQuestion(scanner2);
			if (correct)
				userScore += 1;
		}
		usersScores.put(userName, userScore);
	}

	private static ArrayList<Integer> generateQuestions() {
		ArrayList<Integer> questionIndexs = new ArrayList<>();

		for (int i = 0; i <= 9; i++)
			questionIndexs.add(i);
		Collections.shuffle(questionIndexs);

		return questionIndexs;
	}

	private static void displayMenu() {
		System.out.println("Welcome to exam console:");
		System.out.println("1 -Take an exam");
		System.out.println("2- Display exam results");
		System.out.println("3- Exit");
		System.out.println("Please enter your choice :");
	}

	public static void displayResult() {
		for (String key : usersScores.keySet())
			System.out.println(key + " Got Score: " + usersScores.get(key));

	}
}
