package com.progress.induction.console.exam.etypes;

import java.util.ArrayList;
import java.util.Scanner;

public class EssayQuestion extends Question {
	private String correctAnswer;

	public EssayQuestion(String questionContent, ArrayList<String> choices, String correctAnswer) {
		// TODO Auto-generated constructor stub
		super(questionContent, choices);
		this.correctAnswer = correctAnswer;

	}

	@Override
	public boolean displayQuestion(Scanner scanner) {
		// TODO Auto-generated method stub
		System.out.println(this.getQuestionContent());
		System.out.println("Your Answer? ");
		String answer = scanner.next().trim();
		if (this.correctAnswer.equalsIgnoreCase(answer)) {
			return true;
		}
		return false;

	}

}
