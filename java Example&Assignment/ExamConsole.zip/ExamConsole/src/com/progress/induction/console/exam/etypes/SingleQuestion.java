package com.progress.induction.console.exam.etypes;

import java.util.ArrayList;
import java.util.Scanner;

public class SingleQuestion extends Question {
	private int correctAnswer;

	public SingleQuestion(String questionContent, ArrayList<String> choices, int correctAnswer) {
		// TODO Auto-generated constructor stub
		super(questionContent, choices);
		this.correctAnswer = correctAnswer;

	}

	@Override
	public boolean displayQuestion(Scanner scanner) {
		System.out.println(this.getQuestionContent());
		for (String choice : this.getChoices())
			System.out.println(choice);
		System.out.println("Your Choice ? ");
		int answer = scanner.nextInt();
		if (this.correctAnswer == answer) {
			return true;
		}
		return false;
	}

}
