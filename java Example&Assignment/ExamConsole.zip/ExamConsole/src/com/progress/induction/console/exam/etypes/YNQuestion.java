package com.progress.induction.console.exam.etypes;

import java.util.ArrayList;
import java.util.Scanner;

public class YNQuestion extends Question {

	private char correctAnswer;

	public YNQuestion(String questionContent, ArrayList<String> choices, char correctAnswer) {

		super(questionContent, choices);
		this.correctAnswer = correctAnswer;

	}

	@Override
	public boolean displayQuestion(Scanner scanner) {

		System.out.println(this.getQuestionContent());
		System.out.println("Your Choice (Y/N)? ");
		String answer = scanner.next().trim();

		if (this.correctAnswer == answer.charAt(0))
			return true;

		return false;

	}

}
